package ma.fstt.trackingl;

import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import java.io.IOException;

import java.net.URL;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {

    public void handleGestionLivreur(ActionEvent actionEvent) {
        try {
            // Charger la nouvelle scène FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent root = loader.load();

            // Créer une nouvelle scène
            Scene newScene = new Scene(root);

            // Obtenir l'objet Stage actuel à partir du bouton cliqué
            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();

            // Définir la nouvelle scène
            stage.setScene(newScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void handleGestionProduit(ActionEvent actionEvent) {
        try {
            // Charger la nouvelle scène FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Produit_view.fxml"));
            Parent root = loader.load();

            // Créer une nouvelle scène
            Scene newScene = new Scene(root);

            // Obtenir l'objet Stage actuel à partir du bouton cliqué
            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();

            // Définir la nouvelle scène
            stage.setScene(newScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void handleGestionCommande(ActionEvent actionEvent) {
        try {
            // Charger la nouvelle scène FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("commande_viewTable.fxml"));
            Parent root = loader.load();

            // Créer une nouvelle scène
            Scene newScene = new Scene(root);

            // Obtenir l'objet Stage actuel à partir du bouton cliqué
            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();

            // Définir la nouvelle scène
            stage.setScene(newScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
    }
}

