package ma.fstt.trackingl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import ma.fstt.model.Livreur;
import ma.fstt.model.LivreurDAO;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class HelloController implements Initializable {


    @FXML
    private TextField nom ;


    @FXML
    private TextField tele ;


    @FXML
    private TableView<Livreur> mytable ;


    @FXML
    private TableColumn<Livreur ,Long> col_id ;

    @FXML
    private TableColumn <Livreur ,String> col_nom ;

    @FXML
    private TableColumn <Livreur ,String> col_tele ;


    @FXML
    protected void onSaveButtonClick() {

        // accees a la bdd

        try {
            LivreurDAO livreurDAO = new LivreurDAO();

            Livreur liv = new Livreur(0l , nom.getText() , tele.getText());

            livreurDAO.save(liv);


            UpdateTable();




        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }

@FXML
    public void UpdateTable(){
        col_id.setCellValueFactory(new PropertyValueFactory<Livreur,Long>("id_livreur"));
        col_nom.setCellValueFactory(new PropertyValueFactory<Livreur,String>("nom"));

        col_tele.setCellValueFactory(new PropertyValueFactory<Livreur,String>("telephone"));



        mytable.setItems(this.getDataLivreurs());
    }

    public static ObservableList<Livreur> getDataLivreurs(){

        LivreurDAO livreurDAO = null;

        ObservableList<Livreur> listfx = FXCollections.observableArrayList();

        try {
            livreurDAO = new LivreurDAO();
            for (Livreur ettemp : livreurDAO.getAll())
                listfx.add(ettemp);

        }catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listfx ;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();

        // Ajouter un événement de sélection sur la TableView
        mytable.setOnMouseClicked(event -> {
            Livreur livreur = mytable.getSelectionModel().getSelectedItem();
            if (livreur != null) {
                nom.setText(livreur.getNom());
                tele.setText(livreur.getTelephone());
            }
        });

    }

    @FXML
    private void UpdateligneTable() throws SQLException {
        Livreur livreur = mytable.getSelectionModel().getSelectedItem();
        if (livreur != null) {
            livreur.setNom(nom.getText());
            livreur.setTelephone(tele.getText());
            LivreurDAO livreurDAO = new LivreurDAO();
            livreurDAO.update(livreur);
            mytable.refresh();
        }
    }
    @FXML
    public void Delete(ActionEvent actionEvent) {
        LivreurDAO livreurDAO;
        try {
            livreurDAO = new LivreurDAO();

            // Récupérer la ligne sélectionnée dans le tableau
            Livreur selectedLivreur = mytable.getSelectionModel().getSelectedItem();

            // Supprimer la ligne de la base de données
            livreurDAO.delete(selectedLivreur);

            // Mettre à jour le tableau
            UpdateTable();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void handleRetour(ActionEvent actionEvent) {
        try {
            // Charger la scène précédente FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Dashboard_view.fxml"));
            Parent root = loader.load();

            // Créer une nouvelle scène
            Scene newScene = new Scene(root);

            // Obtenir l'objet Stage actuel à partir du bouton cliqué
            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();

            // Définir la nouvelle scène
            stage.setScene(newScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
