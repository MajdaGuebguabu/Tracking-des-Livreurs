package ma.fstt.trackingl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import ma.fstt.model.Commande;
import ma.fstt.model.CommandeDAO;


import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;



public class CommandeController implements Initializable {

    @FXML
    private TextField dateDebutCommande;
    @FXML
    private TextField dateFinCommande;
    @FXML
    private TextField DistanceF;
    @FXML
    private TextField txtEtat;
    @FXML
    private TextField txtNomL;

    @FXML
    private TableColumn<Commande,Long> IDComn;
    @FXML
    private TableColumn<Commande,String> dateDebut;
    @FXML
    private TableColumn<Commande,String> DateFin;
    @FXML
    private TableColumn<Commande, String> Distance;
    @FXML
    private TableColumn<Commande,String> Etat;
    @FXML
    private TableColumn<Commande, String> Nom_livreur;

    @FXML
    private TableView<Commande> table;

  /*  @FXML
    private Button btnAdd;

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnUpdate;*/


    @FXML
    void Add(ActionEvent event) {
        // accees a la bdd

        try {
            CommandeDAO  commandeDAO = new  CommandeDAO();

            Commande com = new Commande(0l , dateDebutCommande.getText() , dateFinCommande.getText(),DistanceF.getText(),txtEtat.getText(),txtNomL.getText());


            commandeDAO.save(com);


            UpdateTable();




        } catch (SQLException e) {

            throw new RuntimeException(e);
        }



    }
    @FXML
    private void UpdateTable() {

        IDComn.setCellValueFactory(new PropertyValueFactory<Commande,Long>("id"));
        dateDebut.setCellValueFactory(new PropertyValueFactory<Commande,String>("dateDebut"));

        DateFin.setCellValueFactory(new PropertyValueFactory<Commande,String>("dateFin"));

        Distance.setCellValueFactory(new PropertyValueFactory<Commande,String>("distance"));
        Etat.setCellValueFactory(new PropertyValueFactory<Commande,String>("etat"));

        table.getColumns().get(5).setCellValueFactory(new PropertyValueFactory<>("nomlivreur"));



        table.setItems(this.getDataCommandes());
    }

    public static ObservableList<Commande> getDataCommandes() {
        CommandeDAO commandeDAO = null;

        ObservableList<Commande> listfx = FXCollections.observableArrayList();

        try {
            commandeDAO = new CommandeDAO();
            for (Commande ettemp : commandeDAO.getAll())
                listfx.add(ettemp);

        }catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listfx ;
    }

    @FXML
    void UpdateC(ActionEvent event) throws SQLException {
        Commande commande = table.getSelectionModel().getSelectedItem();
        if (commande != null) {
            commande.setDateDebut(dateDebutCommande.getText());
            commande.setDateFin(dateFinCommande.getText());
            commande.setDistance(DistanceF.getText());
            commande.setEtat(txtEtat.getText());
            commande.setNomlivreur(txtNomL.getText());

            CommandeDAO commandeDAO = new CommandeDAO();

            commandeDAO.update(commande);
            table.refresh();
        }

    }
    @FXML
    void Delete(ActionEvent event) {
        CommandeDAO commandeDAO;
        try {
            commandeDAO = new CommandeDAO();

            // Récupérer la ligne sélectionnée dans le tableau
            Commande selectedCommande = table.getSelectionModel().getSelectedItem();

            // Supprimer la ligne de la base de données
            commandeDAO.delete(selectedCommande);

            // Mettre à jour le tableau
            UpdateTable();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        UpdateTable();
        // Ajouter un événement de sélection sur la TableView
        table.setOnMouseClicked(event -> {
            Commande commande = table.getSelectionModel().getSelectedItem();
            if (commande != null) {
                dateDebutCommande.setText(commande.getDateDebut());
                dateFinCommande.setText(commande.getDateFin());
                DistanceF.setText(commande.getDistance());
                txtEtat.setText(commande.getEtat());
                txtNomL.setText(commande.getNomlivreur());

            }
        });




    }

    public void handleRetour(ActionEvent actionEvent) {
        try {
            // Charger la scène précédente FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Dashboard_view.fxml"));
            Parent root = loader.load();

            // Créer une nouvelle scène
            Scene newScene = new Scene(root);

            // Obtenir l'objet Stage actuel à partir du bouton cliqué
            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();

            // Définir la nouvelle scène
            stage.setScene(newScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}