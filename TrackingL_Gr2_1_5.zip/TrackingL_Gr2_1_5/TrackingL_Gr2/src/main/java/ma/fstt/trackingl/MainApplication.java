package ma.fstt.trackingl;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.IOException;

public class MainApplication extends Application {
    @Override
    public void start(Stage stage) {
        // Créer les composants graphiques
        Label labelNom = new Label("Nom : ");
        Label labelModePass = new Label("Mot de passe : ");
        TextField textNom = new TextField();

        // Créer le labelTitre pour "Tracking des Livreurs"
        Label labelTitre = new Label("Tracking des Livreurs");
        labelTitre.setFont(new Font(32));
        labelTitre.setTextFill(Color.ORANGE);
        labelTitre.setAlignment(Pos.CENTER);

        // Créer un conteneur pour le labelTitre
        HBox titleBox = new HBox();
        titleBox.setAlignment(Pos.CENTER);
        titleBox.getChildren().add(labelTitre);

        PasswordField textModePass = new PasswordField();
        Button btnValider = new Button("Valider");
        Button btnQuitter = new Button("Quitter");
        // Appliquer une feuille de style pour rendre les boutons orange
        btnValider.setStyle("-fx-background-color: orange; -fx-text-fill: white; -fx-font: bold italic 16px 'Arial';");
        btnQuitter.setStyle("-fx-background-color: orange; -fx-text-fill: white; -fx-font: bold italic 16px 'Arial';");

        // Créer un ImageView pour afficher le logo
        ImageView imageView = new ImageView(new Image("Screenshot_23-removebg-preview.png"));

// Ajouter le ImageView au conteneur principal
        // Créer un conteneur pour le labelTitre
        HBox imageBox = new HBox();
        imageBox.setAlignment(Pos.CENTER);
        imageBox.getChildren().add(imageView);



        // Ajouter des écouteurs d'événements aux boutons
        btnValider.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (textNom.getText().equals("majda") && textModePass.getText().equals("majda")) {
                    FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Dashboard_view.fxml"));
                    Scene sceneliv = null;
                    try {
                        sceneliv = new Scene(fxmlLoader.load(), 1000, 1000);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }

                    stage.setTitle("Dashboard Administrateur");
                    stage.setScene(sceneliv);
                    stage.show();
                } else {
                    // Afficher un message d'erreur si le nom d'utilisateur ou le mot de passe est incorrect
                    Alert alert = new Alert(Alert.AlertType.ERROR, "Nom d'utilisateur ou mot de passe incorrect");
                    alert.showAndWait();
                }
            }
        });

        btnQuitter.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                stage.close();
            }
        });

        // Créer un conteneur pour les champs de saisie
        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.addRow(0, labelNom, textNom);
        gridPane.addRow(1, labelModePass, textModePass);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHalignment(labelNom, HPos.CENTER);
        gridPane.setHalignment(labelModePass, HPos.CENTER);

        // Créer un conteneur pour les boutons
        HBox hbox = new HBox();
        hbox.setSpacing(10);
        hbox.getChildren().addAll(btnValider, btnQuitter);
        hbox.setAlignment(Pos.CENTER);

        btnValider.setPrefWidth(100); // Définir la taille préférée du bouton
        btnValider.setMaxWidth(100); // Limiter la taille maximale du bouton
        btnQuitter.setPrefWidth(100);
        btnQuitter.setMaxWidth(100);

        // Créer le conteneur principal et y ajouter les autres conteneurs
        VBox root = new VBox();
        root.setSpacing(20);
        root.setPadding(new Insets(20));
        btnValider.setPrefWidth(104);

        btnQuitter.setPrefWidth(104);
        labelNom.setFont(new Font(22));
        labelModePass.setFont(new Font(22));
        textNom.setPrefWidth(300);

        // Ajouter le labelTitre au conteneur principal
        root.getChildren().add(labelTitre);

        root.setAlignment(Pos.CENTER); // centrer la scène
        root.setAlignment(Pos.CENTER); // centrer la scène verticalement
        root.setAlignment(Pos.CENTER); // centrer le GridPane horizontalement

        // Ajouter les autres conteneurs au conteneur principal
        root.getChildren().addAll(gridPane, hbox);

        Scene scene = new Scene(root, 700, 700);
        stage.setTitle("Authentification");
        stage.setScene(scene);
        stage.show();
    }


    public static void main(String[] args) {
        launch();
    }
}
