package ma.fstt.trackingl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import ma.fstt.model.*;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import static java.lang.Float.valueOf;

public class ProduitController implements Initializable {
    @FXML
    private Button Ajouter;

    @FXML
    private Button Modifier;

    @FXML
    private Button Supprimer;

    @FXML
    private TableColumn<Produit, String> descriptionCol;

    @FXML
    private TextField descriptionTextField;

    @FXML
    private TableColumn<Produit, Long> idCol;

    @FXML
    private TableColumn<Produit, String> nomCol;

    @FXML
    private TextField nomTextField;

    @FXML
    private TableColumn<Produit, Float> prixCol;

    @FXML
    private TextField prixTextField;

    @FXML
    private TableView<Produit> produitTable;
    public void handleAjouter() {
        // accees a la bdd

        try {
            ProduitDAO produitDAODAO = new ProduitDAO();

           Produit pro = new Produit(0l , nomTextField.getText() ,Float.parseFloat(prixTextField.getText()),descriptionTextField.getText());
            produitDAODAO.save(pro);
            UpdateTable();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
    private void UpdateTable() {
        idCol.setCellValueFactory(new PropertyValueFactory<Produit,Long>("id_produit"));
        nomCol.setCellValueFactory(new PropertyValueFactory<Produit,String>("Nom"));

        prixCol.setCellValueFactory(new PropertyValueFactory<Produit,Float>("prix_unitaire"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<Produit,String>("description"));


        produitTable.setItems(this.getDataProduit());
    }

    public static ObservableList<Produit> getDataProduit() {
        ProduitDAO produitDAO = null;

        ObservableList<Produit> listfx = FXCollections.observableArrayList();

        try {
            produitDAO= new ProduitDAO();
            for (Produit ettemp : produitDAO.getAll())
                listfx.add(ettemp);

        }catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listfx ;

    }

     @FXML
     void handleModifier(ActionEvent event) throws SQLException {
        Produit produit = produitTable.getSelectionModel().getSelectedItem();
        if (produit != null) {
            produit.setNom(nomTextField.getText());
            produit.setPrix_unitaire(Float.parseFloat(prixTextField.getText()));
            produit.setDescription(descriptionTextField.getText());
            produit.setDescription(descriptionTextField.getText());
            ProduitDAO produitDAO = new ProduitDAO();

            produitDAO.update(produit);
            produitTable.refresh();
        }
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();

        // Ajouter un événement de sélection sur la TableView
        produitTable.setOnMouseClicked(event -> {
            Produit produit = produitTable.getSelectionModel().getSelectedItem();
            if (produit != null) {
                nomTextField.setText(produit.getNom());
                prixTextField.setText(String.valueOf(produit.getPrix_unitaire()));
                descriptionTextField.setText(produit.getDescription());

            }
        });

    }

    public void handleSupprimer(ActionEvent actionEvent) {
       ProduitDAO produitDAO;
        try {
            produitDAO= new ProduitDAO();

            // Récupérer la ligne sélectionnée dans le tableau
            Produit selectedProduit= produitTable.getSelectionModel().getSelectedItem();

            // Supprimer la ligne de la base de données
           produitDAO.delete(selectedProduit);

            // Mettre à jour le tableau
            UpdateTable();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void handleRetour(ActionEvent actionEvent) {
        try {
            // Charger la scène précédente FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Dashboard_view.fxml"));
            Parent root = loader.load();

            // Créer une nouvelle scène
            Scene newScene = new Scene(root);

            // Obtenir l'objet Stage actuel à partir du bouton cliqué
            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();

            // Définir la nouvelle scène
            stage.setScene(newScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

