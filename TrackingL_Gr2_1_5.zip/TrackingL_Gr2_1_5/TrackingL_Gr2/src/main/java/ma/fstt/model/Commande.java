package ma.fstt.model;


public class Commande  {
    private Long id;

    private String dateDebut;
    private String dateFin;
    private String distance;
    private String etat;
    private String nom_livreur;
    public Commande() {
    }

    public Commande(Long id, String dateDebut, String dateFin, String distance, String etat,String nom_livreur) {
        this.id = id;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.distance = distance;
        this.etat = etat;
        this.nom_livreur = nom_livreur;

    }




    public String getDateDebut() {
        return dateDebut;
    }

    public String getDateFin() {
        return dateFin;
    }

    public String getDistance() {
        return distance;
    }

    public String getEtat() {
        return etat;
    }
    public String getNomlivreur() {
        return nom_livreur;
    }

    public Long getId() {
        return id;
    }



    public void setDateDebut(String dateDebut) {
        this.dateDebut = dateDebut;
    }

    public void setDateFin(String dateFin) {
        this.dateFin = dateFin;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }
    public void setNomlivreur(String nom_livreur) {
        this.nom_livreur = nom_livreur;
    }




    @Override
    public String toString() {
        return "Commande{" +
                "Date_debut=" + dateDebut  +
                ", Date_fin='" + dateFin  + '\'' +
                ", Distance='" +  distance + '\'' + "Etat" +  etat + "Nom Livreur" + nom_livreur+
                '}';
    }
}