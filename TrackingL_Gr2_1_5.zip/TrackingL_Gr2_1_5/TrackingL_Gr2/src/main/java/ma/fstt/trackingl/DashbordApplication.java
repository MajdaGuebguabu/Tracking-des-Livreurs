package ma.fstt.trackingl;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class DashbordApplication extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        // Charger la scène FXML principale
        Button btnRetour = new Button("Retour");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("dashboard.fxml"));
        Parent root = loader.load();

        // Créer une nouvelle scène
        Scene scene = new Scene(root, 700, 700);

        // Définir la scène principale
        primaryStage.setTitle("Ma Application");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

