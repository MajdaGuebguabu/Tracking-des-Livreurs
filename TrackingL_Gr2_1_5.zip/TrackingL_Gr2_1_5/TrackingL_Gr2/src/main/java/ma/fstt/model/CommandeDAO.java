package ma.fstt.model;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ma.fstt.model.CommandeDAO;

public class CommandeDAO extends BaseDAO<Commande>{
    public CommandeDAO() throws SQLException {


        super();
    }

    /**
     * @param object
     * @throws SQLException
     */
    @Override
    public void save(Commande object) throws SQLException {
        String requestC = "insert into commande ( date_debut ,date_fin,distance,etat,nom_livreur) values (?,?,?,?,?)";

        // mapping objet table

        this.preparedStatement = this.connection.prepareStatement(requestC);
        // mapping

        this.preparedStatement.setString(1, object.getDateDebut());
        this.preparedStatement.setString(2 , object.getDateFin());
        this.preparedStatement.setString(3 , object.getDistance());
        this.preparedStatement.setString(4, object.getEtat());
        this.preparedStatement.setString(5, object.getNomlivreur());


        this.preparedStatement.execute();

    }

    @Override
    public void update(Commande object) throws SQLException {

        String request = "update commande set date_debut=? ,date_fin=?,distance=?,etat=?,nom_livreur=? where id=?";

        // mapping objet table
        this.preparedStatement = this.connection.prepareStatement(request);
        // mapping

        this.preparedStatement.setString(1 , object.getDateDebut());
        this.preparedStatement.setString(2 , object.getDateFin());
        this.preparedStatement.setString(3 , object.getDistance());
        this.preparedStatement.setString(4 , object.getEtat());
        this.preparedStatement.setString(5 , object.getNomlivreur());
        this.preparedStatement.setLong(6 , object.getId());

        this.preparedStatement.executeUpdate();

    }

    @Override
    public void delete(Commande object) throws SQLException {
        String request = "delete from commande where id=?";

        // mapping objet table
        this.preparedStatement = this.connection.prepareStatement(request);
        // mapping
        this.preparedStatement.setLong(1 , object.getId());

        this.preparedStatement.executeUpdate();

    }

    @Override
    public List<Commande> getAll() throws SQLException {
        List<Commande> mylistC = new ArrayList<Commande>();

        String request = "select * from commande ";

        this.statement = this.connection.createStatement();

        this.resultSet =   this.statement.executeQuery(request);

// parcours de la table
        while ( this.resultSet.next()){

// mapping table objet
            mylistC.add(new Commande(this.resultSet.getLong(1) ,
                    this.resultSet.getString(2) , this.resultSet.getString(3),this.resultSet.getString(4),this.resultSet.getString(5),this.resultSet.getString(6)));


        }


        return mylistC;

    }

    @Override
    public Commande getOne(Long id) throws SQLException {
        return null;
    }


}


